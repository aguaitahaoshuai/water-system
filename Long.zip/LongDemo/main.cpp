#include <iostream>
#include <fstream>
#include <fcntl.h>
#include <termios.h>
#include <unistd.h>
#include <csignal>
#include <string>
#include <chrono>
#include <ctime>
#include <iomanip>
#include <thread>
#include <cstring>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>

// 全局变量，用于标记是否收到 SIGINT 信号
volatile sig_atomic_t g_interrupted = 0;

// SIGINT 信号处理程序
void signal_handler(int signum) {
    g_interrupted = 1;
}

void send_data_to_server(int clientSocket, double Purity, double PH, double TEMP, int Warning) {
    std::stringstream data_stream;
    data_stream << Purity << "|" << PH << "|" << TEMP << "|" << Warning;

    std::string data = data_stream.str();
    if (send(clientSocket, data.c_str(), data.length(), 0) == -1) {
        std::cerr << "错误：发送数据到服务器失败" << std::endl;
    }
}

const std::string SERVER_IP = "120.55.188.97";  // 服务器的IP地址
const int SERVER_PORT = 11666;              // 服务器的端口号

int main() {
    // 设置 SIGINT 信号处理程序
    signal(SIGINT, signal_handler);

    // 串口配置
    int serial_port = open("/dev/ttyS3", O_RDONLY);

    if (serial_port < 0) {
        std::cout << "无法打开串口" << std::endl;
        return -1;
    }

    struct termios tty;
    tcgetattr(serial_port, &tty);

    // 设置波特率
    cfsetispeed(&tty, B115200); // 根据实际情况更改波特率
    cfsetospeed(&tty, B115200);

    tty.c_cflag |= (CLOCAL | CREAD); // 忽略调制解调器控制线并启用接收器
    tty.c_cflag &= ~PARENB; // 无奇偶校验
    tty.c_cflag &= ~CSTOPB; // 一个停止位
    tty.c_cflag &= ~CSIZE; // 清除字节大小位
    tty.c_cflag |= CS8; // 8位数据位

    tcsetattr(serial_port, TCSANOW, &tty); // 设置串口属性

    // 创建文件并打开以保存数据
    std::ofstream file("Log.txt", std::ios::out);

    if (!file.is_open()) {
        std::cout << "无法打开文件" << std::endl;
        close(serial_port);
        return -1;
    }

    // 创建TCP客户端套接字
    int clientSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (clientSocket == -1) {
        std::cerr << "错误：无法创建套接字" << std::endl;
        close(serial_port);
        file.close();
        return 1;
    }

    // 设置服务器地址信息
    sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(SERVER_PORT);
    inet_pton(AF_INET, SERVER_IP.c_str(), &serverAddr.sin_addr);

    // 连接到服务器
    if (connect(clientSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) == -1) {
        std::cerr << "错误：连接服务器失败" << std::endl;
        close(serial_port);
        file.close();
        close(clientSocket);
        return 1;
    }

    // 循环从串口接收数据并提取值
    char buffer[1024];
    ssize_t bytesRead;

    while (!g_interrupted) { // 继续循环直到收到SIGINT信号
        bytesRead = read(serial_port, buffer, sizeof(buffer));

        if (bytesRead > 0) {
            std::string data(buffer, bytesRead);
            // 获取当前时间戳
            auto now = std::chrono::system_clock::now();
            std::time_t now_time = std::chrono::system_clock::to_time_t(now);

            // 将时间戳转换为所需格式"2023-07-16 21:07:54"
            std::stringstream ss;
            ss << std::put_time(std::localtime(&now_time), "%Y-%m-%d %H:%M:%S");
            std::string timestamp = ss.str();

            // 输出带时间戳的数据
            std::cout << "[" << timestamp << "] " << data;

            // 查找数据格式子字符串的位置
            size_t pty_pos = data.find("Pty:");
            size_t ph_pos = data.find("PH:");
            size_t temp_pos = data.find("TEMP:");
            size_t war_pos = data.find("War:");

            // 提取数据并存储在变量中
            double Purity = 0.0;
            double PH = 0.0;
            double TEMP = 0.0;
            int Warning = 0;

            if (pty_pos != std::string::npos) {
                try {
                    Purity = std::stod(data.substr(pty_pos + 4)); // +4跳过"Pty:"
                } catch (const std::invalid_argument& e) {
                    // 处理错误，例如忽略该值或打印错误消息
                    std::cerr << "转换浊度时出错: " << e.what() << std::endl;
                    Purity = 0.0; // 设置默认值或适当的错误值
                }
            }
            if (ph_pos != std::string::npos) {
                try {
                    PH = std::stod(data.substr(ph_pos + 3)); // +3跳过"PH:"
                } catch (const std::invalid_argument& e) {
                    // 处理错误，例如忽略该值或打印错误消息
                    std::cerr << "转换PH值时出错: " << e.what() << std::endl;
                    PH = 0.0; // 设置默认值或适当的错误值
                }
            }
            if (temp_pos != std::string::npos) {
                try {
                    TEMP = std::stod(data.substr(temp_pos + 5)); // +5跳过"TEMP:"
                } catch (const std::invalid_argument& e) {
                    // 处理错误，例如忽略该值或打印错误消息
                    std::cerr << "转换温度时出错: " << e.what() << std::endl;
                    TEMP = 0.0; // 设置默认值或适当的错误值
                }
            }
            if (war_pos != std::string::npos) {
                try {
                    Warning = std::stoi(data.substr(war_pos + 4)); // +4跳过"War:"
                } catch (const std::invalid_argument& e) {
                    // 处理错误，例如忽略该值或打印错误消息
                    std::cerr << "转换警告时出错: " << e.what() << std::endl;
                    Warning = 0; // 设置默认值或适当的错误值
                }
            }

            printf("浊度:%.2f PH值:%.2f 温度:%.1f 警告:%d\n", Purity, PH, TEMP, Warning);

            // 将带时间戳的数据写入文件
            file << "[" << timestamp << "] " << data;

            // 通过TCP套接字将提取的数据发送到服务器
            send_data_to_server(clientSocket, Purity, PH, TEMP, Warning);

            // 在再次读取数据之前添加5秒的延迟
            std::this_thread::sleep_for(std::chrono::seconds(5));
        }
    }

    // 关闭文件和串口连接
    file.close();
    close(serial_port);

    // 关闭TCP客户端套接字
    close(clientSocket);

    // 收到SIGINT信号
    std::cout << "由于收到SIGINT信号，数据记录已停止。" << std::endl;

    return 0;
}


