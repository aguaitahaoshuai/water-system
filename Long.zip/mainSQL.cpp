#include <iostream>
#include <cstring>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <unistd.h>
#include <mysql/mysql.h> // MySQL Connector/C++ 头文件
const int SERVER_PORT = 11666;

struct SensorData {
    double Purity;
    double PH;
    double TEMP;
    int Warning;
};

bool extractSensorData(const std::string& message, SensorData& data) {
    // 自定义的分隔符解析逻辑
    // 假设数据格式为：Purity|PH|TEMP|Warning
    size_t pos1 = message.find('|');
    size_t pos2 = message.find('|', pos1 + 1);
    size_t pos3 = message.find('|', pos2 + 1);

    if (pos1 == std::string::npos || pos2 == std::string::npos || pos3 == std::string::npos) {
        return false;
    }

    try {
        data.Purity = std::stod(message.substr(0, pos1));
        data.PH = std::stod(message.substr(pos1 + 1, pos2 - pos1 - 1));
        data.TEMP = std::stod(message.substr(pos2 + 1, pos3 - pos2 - 1));
        data.Warning = std::stoi(message.substr(pos3 + 1));
    } catch (std::exception& e) {
        return false;
    }

    return true;
}

int main() {
    int serverSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (serverSocket == -1) {
        std::cerr << "错误：无法创建套接字" << std::endl;
        return 1;
    }

    sockaddr_in serverAddr;
    serverAddr.sin_family = AF_INET;
    serverAddr.sin_port = htons(SERVER_PORT);
    serverAddr.sin_addr.s_addr = INADDR_ANY;

    if (bind(serverSocket, (struct sockaddr*)&serverAddr, sizeof(serverAddr)) == -1) {
        std::cerr << "错误：绑定失败" << std::endl;
        close(serverSocket);
        return 1;
    }

    if (listen(serverSocket, 5) == -1) {
        std::cerr << "错误：监听失败" << std::endl;
        close(serverSocket);
        return 1;
    }

    std::cout << "服务器正在监听端口 " << SERVER_PORT << std::endl;

    // MySQL 数据库连接
    MYSQL* conn = mysql_init(nullptr);
    if (conn == nullptr) {
        std::cerr << "MySQL 初始化错误" << std::endl;
        close(serverSocket);
        return 1;
    }

    if (mysql_real_connect(conn, "106.126.9.3", "root", "Tianya0820666..", "water", 0, nullptr, 0) == nullptr) {
        std::cerr << "MySQL 连接错误：" << mysql_error(conn) << std::endl;
        close(serverSocket);
        mysql_close(conn);
        return 1;
    }

    std::cout << "已连接到 MySQL 数据库" << std::endl;

    sockaddr_in clientAddr;
    socklen_t clientAddrSize = sizeof(clientAddr);
    int clientSocket = accept(serverSocket, (struct sockaddr*)&clientAddr, &clientAddrSize);
    if (clientSocket == -1) {
        std::cerr << "错误：接受连接失败" << std::endl;
        close(serverSocket);
        mysql_close(conn);
        return 1;
    }

    char buffer[1024];
    int bytesRead;

    while (true) {
        bytesRead = recv(clientSocket, buffer, sizeof(buffer), 0);
        if (bytesRead <= 0) {
            break;
        }

        buffer[bytesRead] = '\0';
        std::string receivedData(buffer);

        SensorData data;
        if (extractSensorData(receivedData, data)) {
            std::cout << "接收到浊度值：" << data.Purity << std::endl;
            std::cout << "接收到PH值：" << data.PH << std::endl;
            std::cout << "接收到温度值：" << data.TEMP << std::endl;
            std::cout << "接收到警告值：" << data.Warning << std::endl;
            std::cout << "--------------" << std::endl;

            // 上传数据到 MySQL 数据库
            std::string query = "INSERT INTO water (purity, ph, temp, warning, create_time, update_time, del_flag) VALUES (";
            query += std::to_string(data.Purity) + ", ";
            query += std::to_string(data.PH) + ", ";
            query += std::to_string(data.TEMP) + ", ";
            query += std::to_string(data.Warning) + ", ";
            query += "FROM_UNIXTIME(UNIX_TIMESTAMP()), ";
            query += "FROM_UNIXTIME(UNIX_TIMESTAMP()), 0)";

            if (mysql_query(conn, query.c_str()) != 0) {
                std::cerr << "MySQL 查询错误：" << mysql_error(conn) << std::endl;
            }
        } else {
            std::cerr << "错误：接收到无效数据" << std::endl;
        }
    }

    close(clientSocket);
    close(serverSocket);

    mysql_close(conn); // 关闭 MySQL 连接

    return 0;
}
